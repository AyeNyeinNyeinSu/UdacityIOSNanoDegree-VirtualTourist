//
//  PhotosData.swift
//  VirtualTourist
//
//  Created by Aye Nyein Nyein Su on 24/05/2023.
//

import Foundation

class PhotosData {
    static var photosData = [Data]()
}
